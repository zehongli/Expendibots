from GiaoGiaoGiao.state import Game
import copy
import random

DEPTH_SIML = 2
EVALUATE_MAX_WHITE = 10
EVALUATE_MAX_BLACK = -10

RATIO_PROPORTION = 0.4
WORTH_BOOM_PROPORTION = 0.4
SHORTEST_SEP_PROPORTION = 0.15
NUMBER_STACK_PROPORTION = 0.05

def AppendNodeToPool(node, node_pool):
    """
    append node to node pool and state pool
    """
    node_pool.append(node)
    # game_pool.append(node[0])





def PrintList(list):
    for something in list:
        print(something)


class ExamplePlayer:

    def __init__(self, colour):
        """
        This method is called once at the beginning of the game to initialise
        your player. You should use this opportunity to set up your own internal
        representation of the game state, and any other information about the 
        game state you would like to maintain for the duration of the game.

        The parameter colour will be a string representing the player your 
        program will play as (White or Black). The value will be one of the 
        strings "white" or "black" correspondingly.
        """
        # TODO: Set up state representation.
        self.colour = colour
        self.game = Game()
        if(self.colour == "white"):
            self.maximizingPlayer = False
        else:
            self.maximizingPlayer = True

    def action(self):
        """
        This method is called at the beginning of each of your turns to request 
        a choice of action from your program.

        Based on the current state of the game, your player should select and 
        return an allowed action to play on this turn. The action must be
        represented based on the spec's instructions for representing actions.
        """
        # TODO: Decide what action to take, and return it
        depth = 1
        available_actions = self.game._available_actions(self.colour)
        available_games_actions = []
        game_action = []
        for action in available_actions:
            possible_game = copy.deepcopy(self.game)
            possible_game_action = copy.deepcopy(game_action)
            evaluate = 0
            possible_game.update(self.colour, action)
            if (self.suicideAction(self.game, possible_game, self.colour) == False):
                possible_game_action.append(possible_game)
                possible_game_action.append(action)
                possible_game_action.append(evaluate)
                available_games_actions.append(possible_game_action)
        #print("number of available game： ", len(available_games_actions))
        evaluate_list = []
        average_token = self.game.averageToken()
        if (average_token <= 5):
            depth = 2
        if (average_token <= 3):
            depth = 4
        for game_action in available_games_actions:
            if (game_action[0].isOver() == False):
                evaluate = self.minimax(game_action[0], self.colour, depth, -float("inf"), float("inf"), self.maximizingPlayer)
                evaluate = evaluate + WORTH_BOOM_PROPORTION * self.worthBoomToEval(self.game, game_action[0], self.colour)
                evaluate = evaluate + SHORTEST_SEP_PROPORTION * self.separationToEval(game_action[0].getShortestSeparation(), game_action[0].getMaxSeparation(), self.colour)
                evaluate = evaluate + NUMBER_STACK_PROPORTION * self.numStackToEval(game_action[0].getNumOfStack(self.colour), self.colour)
            else:
                evaluate = 0
            #evaluate = self.separationToEval(game_action[0].getShortestSeparation(), game_action[0].getMaxSeparation(), self.colour)
            evaluate_list.append(evaluate)
            game_action[2] = evaluate
        
        if (self.colour == "white"):
            priority_evaluate = max(evaluate_list)
        else:
            priority_evaluate = min(evaluate_list)
        
        PrintList(available_games_actions)

        priority_games_actions = []
        for game_action in available_games_actions:
            if (game_action[2] == priority_evaluate):
                priority_games_actions.append(game_action)
        random_index = random.randint(0, len(priority_games_actions)-1)
        return priority_games_actions[random_index][1]

    def update(self, colour, action):
        """
        This method is called at the end of every turn (including your player’s 
        turns) to inform your player about the most recent action. You should 
        use this opportunity to maintain your internal representation of the 
        game state and any other information about the game you are storing.

        The parameter colour will be a string representing the player whose turn
        it is (White or Black). The value will be one of the strings "white" or
        "black" correspondingly.

        The parameter action is a representation of the most recent action
        conforming to the spec's instructions for representing actions.

        You may assume that action will always correspond to an allowed action 
        for the player colour (your method does not need to validate the action
        against the game rules).
        """
        # TODO: Update state representation in response to action.
        self.game.update(colour, action)

    def GeneratAllGame(self, game, colour):
        available_actions = game._available_actions(colour)
        available_game = []
        for action in available_actions:
            possible_game = copy.deepcopy(game)
            possible_game.update(colour, action)
            if (self.suicideAction(game, possible_game, colour) == False):
                available_game.append(possible_game)
        return available_game

    def suicideAction(self, game, possible_game, colour):
        if (colour == "white"):
            if (game.score['white'] != possible_game.score['white'] and game.score['black'] == possible_game.score['black']):
                return True
            else:
                return False
        else:
            if (game.score['black'] != possible_game.score['black'] and game.score['white'] == possible_game.score['white']):
                return True
            else:
                return False

    def evaluateGame(self, game, colour):
        ratio = self.calculateRatio(game)
        evaluate_ratio = self.ratioToEval(game, ratio)
        
        evaluate = (evaluate_ratio * RATIO_PROPORTION)
        return evaluate

    def calculateRatio(self, game):
        if (game.score["white"] > game.score["black"]):
            if(game.score['black'] == 0):
                token_ratio = 12
            else:
                token_ratio = game.score['white'] / game.score['black']
            return token_ratio
        if (game.score["white"] < game.score["black"]):
            if(game.score['white'] == 0):
                token_ratio = 12
            else:
                token_ratio = game.score['black'] / game.score['white']
            return token_ratio
        if (game.score["white"] == game.score["black"]):
            token_ratio = 1
            return token_ratio

    def ratioToEval(self, game, ratio):
        if (game.score["white"] > game.score["black"]):
            evaluate = (ratio / 12) * EVALUATE_MAX_WHITE
            return evaluate
        if (game.score["white"] < game.score["black"]):
            evaluate = (ratio / 12) * EVALUATE_MAX_BLACK
            return evaluate
        if (game.score["white"] == game.score["black"]):
            evaluate = (ratio / 12) * EVALUATE_MAX_WHITE
            return evaluate

    def worthBoomToEval(self, game, possiable_game, colour):
        if (colour == "white"):
            if (self.ratioToEval(game, self.calculateRatio(possiable_game)) > self.ratioToEval(game, self.calculateRatio(game))):
                evaluate = 10
                return evaluate
            else:
                return 0
        else:
            if (self.ratioToEval(game, self.calculateRatio(possiable_game)) < self.ratioToEval(game, self.calculateRatio(game))):
                evaluate = -10
                return evaluate
            else:
                return 0


    def separationToEval(self, separation, MAX_SEP, colour):
        if(colour == "white"):
            evaluate = (1 - (separation - 1) / MAX_SEP) * EVALUATE_MAX_WHITE
            return evaluate
        else:
            evaluate = (1 - (separation - 1) / MAX_SEP) * EVALUATE_MAX_BLACK
            return evaluate

    def numStackToEval(self, numStack, colour):
        maxNumStack = 6
        if(colour == "white"):
            evaluate  = (numStack / maxNumStack) * EVALUATE_MAX_WHITE
            return evaluate
        else:
            evaluate  = (numStack / maxNumStack) * EVALUATE_MAX_BLACK
            return evaluate


    def minimax(self, game, current_colour, depth, alpha, beta, maximizingPlayer):
        next_colour = "white" if current_colour == "black" else "black"
        if (depth == 0 or game.score['white'] == 0 or game.score['black'] == 0):
            return self.evaluateGame(game, current_colour)
        if (maximizingPlayer):
            maxEval = -float("inf")
            child_games = self.GeneratAllGame(game, next_colour)
            current_colour, next_colour = next_colour, current_colour
            for child_game in child_games:
                evaluate = self.minimax(child_game, current_colour,
                                depth-1, alpha, beta, False)
                maxEval = max(maxEval, evaluate)
                alpha = max(alpha, evaluate)
                if (beta <= alpha):
                    break
            return maxEval
        else:
            minEval = float("inf")
            child_games = self.GeneratAllGame(game, next_colour)
            current_colour, next_colour = next_colour, current_colour
            for child_game in child_games:
                evaluate = self.minimax(child_game, current_colour,
                                depth-1, alpha, beta, True)
                minEval = min(minEval, evaluate)
                beta = min(beta, evaluate)
                if (beta <= alpha):
                    break
            return minEval
