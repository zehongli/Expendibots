def action(self):
        """
        This method is called at the beginning of each of your turns to request 
        a choice of action from your program.

        Based on the current state of the game, your player should select and 
        return an allowed action to play on this turn. The action must be
        represented based on the spec's instructions for representing actions.
        """
        # TODO: Decide what action to take, and return it
        available_actions = self.game._available_actions(self.colour)
        available_games_actions = []
        game_action = []
        for action in available_actions:
            possible_game = copy.deepcopy(self.game)
            possible_game_action = copy.deepcopy(game_action)
            evaluate = 0
            possible_game.update(self.colour, action)
            possible_game_action.append(possible_game)
            possible_game_action.append(action)
            possible_game_action.append(evaluate)
            available_games_actions.append(possible_game_action)
        print("number of available game： ", len(available_games_actions))
        for game_action in available_games_actions:
            print("====================================================================")
            print("try action")
            depth = 0
            node_pool = []
            initial_node = []
            initial_node.append(game_action[0])
            initial_node.append(-1)
            AppendNodeToPool(initial_node, node_pool)
            current_nodes = []
            current_nodes.append(initial_node)

            current_colour = self.colour
            next_colour = "white" if self.colour == "black" else "black"
            print(node_pool[0])
            while(depth < DEPTH_SIML):
                depth += 1
                print(depth)
                print("Next colour; ", next_colour)
                all_child_nodes = []
                for current_node in current_nodes:
                    child_games_for_one_node = GeneratAllGame(current_node[0], next_colour)
                    for child_game in child_games_for_one_node:
                        child_node = []
                        child_node.append(copy.deepcopy(child_game))
                        print("---------------------------------------")
                        PrintList(node_pool)
                        print("---------------------------------------")
                        child_node.append(node_pool.index(current_node))
                        all_child_nodes.append(copy.deepcopy(child_node))
                        AppendNodeToPool(copy.deepcopy(child_node), node_pool)
                        # print("pool size:", len(node_pool))
                current_colour, next_colour = next_colour, current_colour
                current_nodes = copy.deepcopy(all_child_nodes)
            PrintList(node_pool)
            print("pool size: ", len(node_pool))

        return available_actions[0]

def evaluateGame(self, game, colour):
        if (game.score['white'] == game.score['black']):
            token_ratio = 1
        if (game.score['white'] == 0):
            token_ratio = 0
        if (game.score['black'] == 0):
            token_ratio = game.score['white']
        if (game.score['white'] != 0 and game.score['black'] != 0):
            token_ratio = game.score['white'] / game.score['black']
        return token_ratio
