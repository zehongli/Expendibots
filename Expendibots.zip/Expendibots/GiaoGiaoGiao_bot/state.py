from collections import Counter
import math

_ALL_SQUARES = {(x, y) for x in range(8) for y in range(8)}

_BLACK_START_SQUARES = [(0, 7), (1, 7),   (3, 7), (4, 7),   (6, 7), (7, 7),
                        (0, 6), (1, 6),   (3, 6), (4, 6),   (6, 6), (7, 6)]
_WHITE_START_SQUARES = [(0, 1), (1, 1),   (3, 1), (4, 1),   (6, 1), (7, 1),
                        (0, 0), (1, 0),   (3, 0), (4, 0),   (6, 0), (7, 0)]


def _NEXT_SQUARES(square, d=1):
    x, y = square
    return {(x, y+d),
            (x-d, y),        (x+d, y),
            (x, y-d)} & _ALL_SQUARES


def _NEAR_SQUARES(square):
    x, y = square
    return {(x-1, y+1), (x, y+1), (x+1, y+1),
            (x-1, y),          (x+1, y),
            (x-1, y-1), (x, y-1), (x+1, y-1)} & _ALL_SQUARES


class IllegalActionException(Exception):
    """If this action is illegal based on the current board state."""


class Game:
    """
    Represent the evolving state of a game. Main useful methods
    are __init__, update, over, end, and __str__.
    """

    def __init__(self):
        # initialise game board state:
        self.board = Counter({xy: 0 for xy in _ALL_SQUARES})
        for xy in _WHITE_START_SQUARES:
            self.board[xy] = +1
        for xy in _BLACK_START_SQUARES:
            self.board[xy] = -1
        # also keep track of some other state variables for win/draw
        # detection (score, number of turns, state history)
        self.score = {'white': 12, 'black': 12}

    def update(self, colour, action):
        """
        Submit an action to the game for validation and application.
        If the action is not allowed, raise an InvalidActionException with
        a message describing allowed actions.
        Otherwise, apply the action to the game state.
        """
        available_actions = self._available_actions(colour)
        if action in available_actions:
            atype, *aargs = action
            if atype == "MOVE":
                n, a, b = aargs
                n = -n if self.board[a] < 0 else n
                self.board[a] -= n
                self.board[b] += n
            else:  # atype == "BOOM":
                start_square, = aargs
                to_boom = [start_square]
                for boom_square in to_boom:
                    n = self.board[boom_square]
                    self.score["white" if n > 0 else "black"] -= abs(n)
                    self.board[boom_square] = 0
                    for near_square in _NEAR_SQUARES(boom_square):
                        if self.board[near_square] != 0:
                            to_boom.append(near_square)
        # TODO: return a sanitised version of the action?

    def _available_actions(self, colour):
        """
        A list of currently-available actions for a particular player
        (assists validation).
        """
        available_actions = []
        if colour == "white":
            stacks = +self.board
        else:
            stacks = -self.board
        for square in stacks.keys():
            available_actions.append(("BOOM", square))
        for square, n in stacks.items():
            for d in range(1, n+1):
                for next_square in _NEXT_SQUARES(square, d):
                    if next_square in stacks or self.board[next_square] == 0:
                        for m in range(1, n+1):
                            move_action = ("MOVE", m, square, next_square)
                            available_actions.append(move_action)
        return available_actions

    def averageToken(self):
        average = (self.score['white'] + self.score['black']) / 2
        return average

    def getNumOfStack(self, colour):
        counter = 0
        for coordinate in self.board:
            if (colour == "white"):
                if (self.board[coordinate] >= 2):
                    counter += 1
            else:
                if (self.board[coordinate] <= -2):
                    counter += 1
        return counter

    def calculateSeparation(self, oneside_coord, otherside_coord):
        oneside_x = oneside_coord[0]
        oneside_y = oneside_coord[1]
        otherside_x = otherside_coord[0]
        otherside_y = otherside_coord[1]

        distance = math.sqrt(
            math.pow(oneside_x - otherside_x, 2) + math.pow(oneside_y - otherside_y, 2))

        return distance

    def getShortestSeparation(self):
        distance_list = []
        for oneside_coord in self.board:
            if (self.board[oneside_coord] > 0):
                for otherside_coord in self.board:
                    if (self.board[otherside_coord] < 0):
                        distance = self.calculateSeparation(
                            oneside_coord, otherside_coord)
                        distance_list.append(distance)
        min_separation = min(distance_list)
        #print(min_separation)
        return min_separation

    def getMaxSeparation(self):
      return 7*math.sqrt(2)

    def isOver(self):
      if (min(self.score.values()) == 0):
        return True
      else:
        return False
